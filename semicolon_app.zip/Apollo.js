const options = {
    uri: "https://semicolon-backend.herokuapp.com"
};

export default options;
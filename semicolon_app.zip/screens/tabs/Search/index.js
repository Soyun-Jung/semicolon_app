import Search from "./SearchContainer";

export default Search;